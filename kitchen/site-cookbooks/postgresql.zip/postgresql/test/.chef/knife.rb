cache_type "BasicFile"
cache_options(path: "#{ENV["HOME"]}/.chef/checksums")
